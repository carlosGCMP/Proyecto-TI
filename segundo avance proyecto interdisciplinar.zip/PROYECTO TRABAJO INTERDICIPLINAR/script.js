// script.js
let timer;
let timeLeft = 1500;
let isPaused = false;
let currentMode = 'pomodoro';

const displayMinutes = document.getElementById('minutes');
const displaySeconds = document.getElementById('seconds');
const zenImage = document.getElementById('zen-image');
const zenCaption = document.getElementById('zen-caption');
const zenMusic = document.getElementById('zen-music');
const monthSelector = document.getElementById("month-selector");
const body = document.body;

const themes = {
  pomodoro: {
    time: 5,
    bgColor: '#f9f9f6',
    containerBg: '#fff',
    text: 'Respira profundo, todo empieza con calma.',
    img: 'assets/Images/focus.gif'
  },
  short: {
    time: 300,
    bgColor: '#e0f7fa',
    containerBg: '#ffffff',
    text: 'Toma un respiro corto y relaja tu mente.',
    img: 'assets/Images/shortbreak.gif'
  },
  long: {
    time: 900,
    bgColor: '#e8f5e9',
    containerBg: '#ffffff',
    text: 'Descansa profundamente y renueva energías.',
    img: 'assets/Images/longbreak.gif'
  }
};

function updateTheme(mode) {
  const theme = themes[mode];
  document.querySelector('.container').style.backgroundColor = theme.containerBg;
  body.style.backgroundColor = theme.bgColor;
  zenImage.src = theme.img;
  zenCaption.textContent = theme.text;
}

function setTimer(mode) {
  clearInterval(timer);
  currentMode = mode;
  timeLeft = themes[mode].time;
  updateDisplay();
  updateTheme(mode);
  updateProgress();
}

function updateDisplay() {
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  displayMinutes.textContent = minutes.toString().padStart(2, '0');
  displaySeconds.textContent = seconds.toString().padStart(2, '0');
}

function updateProgress() {
  const duration = themes[currentMode].time;
  const percent = 100 - (timeLeft / duration) * 100;
  document.getElementById("progress-bar").style.width = percent + "%";
}

function startTimer() {
  if (isPaused) {
    isPaused = false;
  } else {
    updateTheme(currentMode);
  }

  clearInterval(timer);
  timer = setInterval(() => {
    if (!isPaused) {
      timeLeft--;
      updateDisplay();
      updateProgress();
      if (timeLeft <= 0) {
        clearInterval(timer);
        alert('Tiempo finalizado.');
        updateStats(currentMode);
      }
    }
  }, 1000);
}

function pauseTimer() {
  isPaused = true;
}

function toggleMusic() {
  zenMusic.paused ? zenMusic.play() : zenMusic.pause();
}

function updateStats(mode) {
  const stats = JSON.parse(localStorage.getItem("timebox-stats")) || {};
  const today = new Date().toISOString().split("T")[0];
  if (!stats[today]) stats[today] = { pomodoro: 0, short: 0, long: 0, totalMinutes: 0 };
  stats[today][mode]++;
  stats[today].totalMinutes += themes[mode].time / 60;
  localStorage.setItem("timebox-stats", JSON.stringify(stats));
}

function showStats() {
  const rawStats = JSON.parse(localStorage.getItem("timebox-stats")) || {};
  const selectedMonth = monthSelector.value;
  const labels = [];
  const pomodoros = [];

  Object.keys(rawStats)
    .filter(date => date.startsWith(selectedMonth))
    .sort()
    .forEach(date => {
      labels.push(date.slice(8));
      pomodoros.push(rawStats[date].pomodoro || 0);
    });

  const ctx = document.getElementById("statsChart").getContext("2d");
  if (window.statsChart instanceof Chart) window.statsChart.destroy();
  window.statsChart = new Chart(ctx, {
    type: "line",
    data: {
      labels,
      datasets: [{
        label: "Pomodoros por día",
        data: pomodoros,
        borderColor: "#ff6b6b",
        backgroundColor: "rgba(255, 107, 107, 0.2)",
        fill: true
      }]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: "Pomodoros - " + selectedMonth
        },
        legend: { display: false }
      }
    }
  });
  document.getElementById("stats-modal").style.display = "block";
}

function closeStats() {
  document.getElementById("stats-modal").style.display = "none";
}

function populateMonthSelector() {
  const stats = JSON.parse(localStorage.getItem("timebox-stats")) || {};
  const months = new Set(Object.keys(stats).map(date => date.slice(0, 7)));
  monthSelector.innerHTML = "";
  months.forEach(month => {
    const option = document.createElement("option");
    option.value = month;
    option.textContent = month;
    monthSelector.appendChild(option);
  });
  const currentMonth = new Date().toISOString().slice(0, 7);
  monthSelector.value = currentMonth;
}

function toggleTheme() {
  body.classList.toggle("dark-mode");
}

function exportStats() {
  const rawStats = JSON.parse(localStorage.getItem("timebox-stats")) || {};
  let csv = "Fecha,Pomodoros,Short,Long,TotalMinutos\n";
  Object.keys(rawStats).forEach(date => {
    const entry = rawStats[date];
    csv += `${date},${entry.pomodoro},${entry.short},${entry.long},${entry.totalMinutes}\n`;
  });
  const blob = new Blob([csv], { type: "text/csv" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = "timebox_stats.csv";
  a.click();
}
window.addEventListener("keydown", (e) => {
  if (e.key === "Escape") closeStats();
});
window.addEventListener("click", (e) => {
  if (e.target === document.getElementById("stats-modal")) closeStats();
});
window.addEventListener("beforeunload", () => {
  const sessionData = { timeLeft, currentMode, isPaused };
  localStorage.setItem("timebox-session", JSON.stringify(sessionData));
});
window.addEventListener("DOMContentLoaded", () => {
  const saved = JSON.parse(localStorage.getItem("timebox-session"));
  if (saved) {
    timeLeft = saved.timeLeft;
    currentMode = saved.currentMode;
    isPaused = saved.isPaused;
    updateDisplay();
    updateTheme(currentMode);
  } else {
    setTimer('pomodoro');
  }
  populateMonthSelector();
});
function exportCSV() {
  const rawStats = JSON.parse(localStorage.getItem("timebox-stats")) || {};

  if (Object.keys(rawStats).length === 0) {
    alert("No hay datos para exportar.");
    return;
  }

  let csv = "Fecha,Pomodoros,Descansos Cortos,Descansos Largos,Minutos Totales\n";

  for (const date in rawStats) {
    const day = rawStats[date];
    csv += `${date},${day.pomodoro || 0},${day.short || 0},${day.long || 0},${day.totalMinutes || 0}\n`;
  }

  const blob = new Blob([csv], { type: "text/csv" });
  const url = URL.createObjectURL(blob);

  const a = document.createElement("a");
  a.href = url;
  a.download = "estadisticas_timebox.csv";
  a.click();
  URL.revokeObjectURL(url);
};