let timer;
let timeLeft = 1500;
let isPaused = false;
let currentMode = 'pomodoro';

const displayMinutes = document.getElementById('minutes');
const displaySeconds = document.getElementById('seconds');
const zenImage = document.getElementById('zen-image');
const zenCaption = document.getElementById('zen-caption');
const zenMusic = document.getElementById('zen-music');

const themes = {
pomodoro: {
time: 1500,
bgColor: '#f9f9f6',
containerBg: '#fff',
text: 'Respira profundo, todo empieza con calma.',
img: 'assets/Images/focus.gif'
},
short: {
time: 300,
bgColor: '#e0f7fa',
containerBg: '#ffffff',
text: 'Toma un respiro corto y relaja tu mente.',
img: 'assets/Images/shortbreak.gif'
},
long: {
time: 900,
bgColor: '#e8f5e9',
containerBg: '#ffffff',
text: 'Descansa profundamente y renueva energías.',
img: 'assets/Images/longbreak.gif'
}
};

function updateTheme(mode) {
const theme = themes[mode];
document.body.style.backgroundColor = theme.bgColor;
document.querySelector('.container').style.backgroundColor = theme.containerBg;
zenImage.src = theme.img;
zenCaption.textContent = theme.text;
}

function setTimer(mode) {
clearInterval(timer);
currentMode = mode;
timeLeft = themes[mode].time;
updateDisplay();
updateTheme(mode);
}

function updateDisplay() {
const minutes = Math.floor(timeLeft / 60);
const seconds = timeLeft % 60;
displayMinutes.textContent = minutes.toString().padStart(2, '0');
displaySeconds.textContent = seconds.toString().padStart(2, '0');
}

function startTimer() {
if (isPaused) {
isPaused = false;
} else {
updateTheme(currentMode);
}

clearInterval(timer);
timer = setInterval(() => {
if (!isPaused) {
timeLeft--;
updateDisplay();
if (timeLeft <= 0) {
clearInterval(timer);
alert('Tiempo finalizado.');
updateStats(currentMode);
}
}
}, 1000);
}

function pauseTimer() {
isPaused = true;
}

function toggleMusic() {
if (zenMusic.paused) {
zenMusic.play();
} else {
zenMusic.pause();
}
}

function updateStats(mode) {
let stats = JSON.parse(localStorage.getItem("timebox-stats")) || {
pomodoro: 0,
short: 0,
long: 0,
totalMinutes: 0
};

stats[mode]++;
if (mode === 'pomodoro') {
stats.totalMinutes += 25;
} else if (mode === 'short') {
stats.totalMinutes += 5;
} else if (mode === 'long') {
stats.totalMinutes += 15;
}

localStorage.setItem("timebox-stats", JSON.stringify(stats));
}

function showStats() {
  const stats = JSON.parse(localStorage.getItem("timebox-stats")) || {
  pomodoro: 0,
  short: 0,
  long: 0,
  totalMinutes: 0
  };
  document.getElementById("pomodoro-count").textContent = stats.pomodoro;
  document.getElementById("short-count").textContent = stats.short;
  document.getElementById("long-count").textContent = stats.long;
  document.getElementById("total-minutes").textContent = stats.totalMinutes;
  const ctx = document.getElementById("statsChart").getContext("2d");
  if (window.statsChart instanceof Chart) {
    window.statsChart.destroy();
  }
  window.statsChart = new Chart(ctx, {
  type: "bar",
  data: {
  labels: ["Pomodoro", "Descanso Corto", "Descanso Largo"],
  datasets: [{
  label: "Sesiones completadas",
  data: [stats.pomodoro, stats.short, stats.long],
  backgroundColor: ["#f44336", "#29b6f6", "#66bb6a"]
  }]
  },
  options: {
  responsive: true,
  plugins: {
  legend: { display: false },
  title: {
  display: true,
  text: "Tiempo Total: " + stats.totalMinutes + " minutos"
  }
  }
  }
  });
  
  document.getElementById("stats-modal").style.display = "block";
  }
setTimer('pomodoro');
function closeStats() {
  document.getElementById("stats-modal").style.display = "none";
}
window.addEventListener("keydown", function (e) {
  if (e.key === "Escape") {
    closeStats();
  }
});

window.addEventListener("click", function (e) {
  const modal = document.getElementById("stats-modal");
  if (e.target === modal) {
    closeStats();
  }
});

